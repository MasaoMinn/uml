__turbopack_load_page_chunks__("/_app", [
  "static/chunks/d3a6f0f4299f25b2.js",
  "static/chunks/31b3d9daffc0f450.js",
  "static/chunks/73a167fb5a80f186.js"
])
