__turbopack_load_page_chunks__("/example", [
  "static/chunks/c5ca9ddf5c8aca8c.js",
  "static/chunks/31b3d9daffc0f450.js",
  "static/chunks/e67f2347bc87310f.js"
])
